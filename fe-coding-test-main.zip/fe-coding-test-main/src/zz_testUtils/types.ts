export type ApiError = {
  message: string;
};
