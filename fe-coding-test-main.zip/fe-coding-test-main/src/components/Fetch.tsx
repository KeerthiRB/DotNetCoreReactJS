import React from 'react'

export const FetchTask = () => {
  return <div>Your code goes here</div>;
};
