import React from 'react'

export const AccountsTask = () => {
  return <div>Your code goes here</div>;
};
